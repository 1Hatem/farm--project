package com.example.ASWAN AGRO SMART

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
